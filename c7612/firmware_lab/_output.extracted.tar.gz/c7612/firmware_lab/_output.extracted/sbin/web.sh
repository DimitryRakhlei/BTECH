# reload web server alphapd
killall -q alphapd
sleep 1
alphapd &

