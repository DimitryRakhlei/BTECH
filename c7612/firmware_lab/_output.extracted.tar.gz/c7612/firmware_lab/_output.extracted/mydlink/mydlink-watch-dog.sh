#!/bin/sh

########################
# http server checking #
########################
MAX_COUNT=5
MYDLINK_BASE="/mydlink"
PID_BASE="/tmp/run"
LOG_BASE="/tmp/md-log"

LOG_FILE="${LOG_BASE}/mydlink.log"
LOG_MAX_SZ=500000

DEV_CMD="mdb"
PORT_CMD="get http_port"
SPORT_CMD="get https_port"

UNIT_CHECK_T=5
HTTP_CHECK_T=300

STREAM_CGI=""
INFO_CGI="/common/info.cgi"
VIDEO_93x_CGI="/h264.cgi"
VIDEO_NIPCA_CGI="/video/ACVS-H264.cgi"
VIDEO_MJPG_CGI="/video/mjpg.cgi"

HTTP_BASE="http://127.0.0.1"
HTTPS_BASE="https://127.0.0.1"

HTTP_CMD="/mydlink/httpd_check"

############################
# Message logging function #
############################
# $1: message
log() {
  #echo "[`date +"%Y-%m-%d %H:%M:%S"`] $1" >> $LOG_FILE
  echo "[`date +"%Y-%m-%d %H:%M:%S"`] $1" > /dev/null 2>&1
}

restart_httpd_93x() {
  killall -q -9 alphapd
  alphapd& > /dev/null 2>&1
}

restart_httpd_94x() {
  if [ -f "/etc/rc.d/init.d/lighttpd.sh" ]; then
    /etc/rc.d/init.d/lighttpd.sh stop
    /etc/rc.d/init.d/lighttpd.sh start
  fi
}

restart_httpd() {
  # legacy way
  restart_httpd_93x
  restart_httpd_94x
  network_restart

  # new defined way
  mdb set reload_http_service 1 > /dev/null 2>&1
  mdb apply > /dev/null 2>&1
}

##########################
# Video CGI detection    #
##########################
# $1: http port
detect_stream_cgi() {
  stream_path=""
  for path in "${VIDEO_NIPCA_CGI}" "${VIDEO_93x_CGI}" "${VIDEO_MJPG_CGI}"
  do
    code=`${HTTP_CMD} ${HTTP_BASE}:${1}${path}`
    if [ "0${code}" = "0200" ]; then
      stream_path=${path}
      break;
    fi
  done

  if [ "0$stream_path" = "0" ]; then
    return 127
  fi

  log "video CGI '${stream_path}' detected."

  echo $stream_path
}


##########################
# Device httpd checking  #
##########################
#$1: http port
#$2: https port
#$3: stream_path
health_check_httpd() {
  for url in "${HTTP_BASE}:${1}${INFO_CGI}" "${HTTPS_BASE}:${2}${INFO_CGI}" "${HTTP_BASE}:${1}${3}"
  do
    # cgi checking
    count=0
    while [ $count -lt ${MAX_COUNT} ]
    do
      code=`${HTTP_CMD} ${url}`
      #log "${url} -> ${code}"
      if [ "0${code}" != "0200" ]; then
        count=`expr $count + 1`
        sleep 3
      else
        break
      fi
    done

    # retry and failed
    if [ $count -ge ${MAX_COUNT} ]; then
      log "Failed to access ${url}, restarting system services.."
      restart_httpd

      break;
    fi
  done
}


##########################
# mydlink agent checking #
##########################
# $1: process name
# $2: launch argument
check_alive() {
  # check if the program exists or not
  if [ ! -f "$MYDLINK_BASE/$1" ]; then
    return
  fi

  # check if process exists by pid
  pid="-1"
  if [ -f "${PID_BASE}/${1}.pid" ]; then
    pid=`cat ${PID_BASE}/${1}.pid`
  fi
  if [ -d "/proc/${pid}" ]; then
    return
  fi

  log "$1 is not running! ($pid)"
  # kill all remaining processes and wait a moment
  killall -q $1 2>/dev/null
  sleep 1

  # launch the process
  # $MYDLINK_BASE/$1 $2 >> "${LOG_BASE}/${1}.log" 2>&1 &
  $MYDLINK_BASE/$1 $2 > /dev/null 2>&1 &
  pid="$!"
  res="$?"

  # keep the pid
  echo $pid > "${PID_BASE}/${1}.pid"

  log " - launch $1 ($pid, $res)"
}

# $1: folder
validate_log_size() {
  count=0
  size=0
  for it in `ls -l "$1"`
  do
    count=`expr $count % 9 + 1`
    if [ `expr $count % 5` -eq 0 ]; then
      size=`expr $size + $it`
    fi
  done

  if [ $size -ge $LOG_MAX_SZ ]; then
    for file in `ls $1`
    do
      echo "[`date +"%Y-%m-%d %H:%M:%S"`] reset log" > "$1/$file"
    done
    log "Reset logs in folder '$1'"
  fi
}




# Get mydlink folder
if [ -f /mydlink/signalc ]; then
  MYDLINK_BASE="/mydlink"
elif [ -f /opt/signalc ]; then
  MYDLINK_BASE="/opt"
fi

HTTP_CMD="$MYDLINK_BASE/httpd_check" 

# Set mydlink into PATH
export PATH="$MYDLINK_BASE:$PATH"

# Get model name
MODEL_NAME="Unknown"
HAS_MDB=`mdb get dev_model | grep "L" -c` 2>/dev/null
if [ "1" -eq "$HAS_MDB" ]; then
  MODEL_NAME=`mdb get dev_model`

else
  DEV_CMD="tdb"
  PORT_CMD="get HTTPServer Port_num"
  SPORT_CMD="get HTTPServer HTTPSPort_num"

  wlan=`pibinfo Wireless` 2>/dev/null
  if [ "$wlan" = "1" ]; then
    MODEL_NAME=`tdb get System ModelW_ss`
  else
    MODEL_NAME=`tdb get System Model_ss`
  fi
fi


# Get LAN interface
LAN_INT="br0"
HAS_BR0=`ifconfig | grep "br0" -c`
if [ "$HAS_BR0" -ge "1" ]; then
  LAN_INT="br0"
else
  LAN_INT="eth0"
fi


# Make neccessary folders
mkdir -p $PID_BASE
mkdir -p $LOG_BASE


# Wait for self-pid is updated
sleep 1


# Check agent status
runs=0
while [ 1 ]
do
  curpid=`cat ${PID_BASE}/mydlink-watch-dog.pid`
  if [ "$$" -ne "$curpid" ]; then
    log "Unexpected pid (self: $$ cur: $curpid), exit!"
    exit 255
  fi

  # check mydlink agents
  check_alive dcp "-i $LAN_INT -m $MODEL_NAME"
  check_alive signalc

  # check dev http service
  runs=`expr $runs + $UNIT_CHECK_T`
  if [ $runs -ge $HTTP_CHECK_T ]; then
    #check_httpd
    http_port=`$DEV_CMD $PORT_CMD`
    https_port=`$DEV_CMD $SPORT_CMD`

    if [ "0$STREAM_CGI" = "0" ]; then
      STREAM_CGI=`detect_stream_cgi $http_port`
    fi

    health_check_httpd "$http_port" "$https_port" "$STREAM_CGI"

    runs=0
  fi

  sleep $UNIT_CHECK_T
done

